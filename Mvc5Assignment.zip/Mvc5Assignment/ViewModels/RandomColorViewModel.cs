﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Mvc5Assignment.Models;


namespace Mvc5Assignment.ViewModels
{
    public class RandomColorViewModel
    {
        public Colors Colors { get; set; }
        public List<Shades> Shades { get; set; }
    }
}