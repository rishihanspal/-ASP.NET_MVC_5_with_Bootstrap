﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc5Assignment.Models;
using Mvc5Assignment.ViewModels;

namespace Mvc5Assignment.Controllers
{
    public class ColorsController : Controller
    {
        // GET: Colors
        public ActionResult Random()
        {
            var Color = new Colors() { Name = "RED" };
            var Shade = new List<Shades>
            {
                new Shades {Id=1 ,name = "Light"},
                new Shades {Id=2 ,name = "dark" },
                new Shades {Id=3 ,name = "blood" },
                new Shades {Id=4 ,name = "apple" },
                new Shades {Id=5 ,name = "rose" },

            };
            var ViewModel = new RandomColorViewModel
            {
                Colors = Color,
                Shades = Shade
            };
            return View(ViewModel); 
            
        }
        public ActionResult Black()
        {
            var Color = new Colors() { Name = "BLACK" };
            var Shade = new List<Shades>
            {
                new Shades {Id=1, name = "Light"},
                new Shades {Id=2, name = "dark" }, 
                new Shades {Id=3, name = "Greyish"},
                new Shades {Id=4, name = "Blueish"}
            };
            var ViewModel = new RandomColorViewModel
            {
                Colors = Color,
                Shades = Shade
            };
            return View(ViewModel);

        }

        public ActionResult Search()
        {
            return View();
        }

        // public ActionResult ExpiryDate(int year, int month)
        //{
        //  return Content("Best Before : "  +month+'/'+year  );
        // }
    }
}